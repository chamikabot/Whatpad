/**
 * EPUB Generator Utility
 * Creates EPUB eBooks from story data
 * Uses a manual approach since epub-gen may have compatibility issues
 */

const fs = require('fs-extra');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

/**
 * Generate EPUB from story data
 * Creates a valid EPUB 3.0 file manually
 * @param {Object} storyData - Story metadata and chapters
 * @param {string} outputPath - Where to save the EPUB
 */
exports.generate = async (storyData, outputPath) => {
    const tempDir = path.join(path.dirname(outputPath), `epub_temp_${uuidv4()}`);

    try {
        await fs.ensureDir(tempDir);

        // Create EPUB directory structure
        const metaDir = path.join(tempDir, 'META-INF');
        const oebpsDir = path.join(tempDir, 'OEBPS');
        await fs.ensureDir(metaDir);
        await fs.ensureDir(oebpsDir);

        // Generate unique identifier
        const uuid = uuidv4();
        const date = new Date().toISOString();

        // ========== mimetype ==========
        await fs.writeFile(
            path.join(tempDir, 'mimetype'),
            'application/epub+zip'
        );

        // ========== META-INF/container.xml ==========
        const containerXml = `<?xml version="1.0" encoding="UTF-8"?>
<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container">
    <rootfiles>
        <rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/>
    </rootfiles>
</container>`;
        await fs.writeFile(path.join(metaDir, 'container.xml'), containerXml);

        // ========== OEBPS/content.opf ==========
        const manifestItems = storyData.chapters.map((ch, i) => 
            `        <item id="chapter${i}" href="chapter${i}.xhtml" media-type="application/xhtml+xml"/>`
        ).join('\n');

        const spineItems = storyData.chapters.map((ch, i) => 
            `        <itemref idref="chapter${i}"/>`
        ).join('\n');

        const contentOpf = `<?xml version="1.0" encoding="UTF-8"?>
<package version="3.0" xmlns="http://www.idpf.org/2007/opf" xml:lang="en">
    <metadata xmlns:dc="http://purl.org/dc/elements/1.1/">
        <dc:identifier id="bookid">urn:uuid:${uuid}</dc:identifier>
        <dc:title>${escapeXml(storyData.title)}</dc:title>
        <dc:creator>${escapeXml(storyData.author)}</dc:creator>
        <dc:description>${escapeXml(storyData.description || '')}</dc:description>
        <dc:language>en</dc:language>
        <dc:date>${date}</dc:date>
        <meta property="dcterms:modified">${date}</meta>
    </metadata>
    <manifest>
        <item id="toc" href="toc.ncx" media-type="application/x-dtbncx+xml"/>
        <item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>
        <item id="cover" href="cover.xhtml" media-type="application/xhtml+xml"/>
${manifestItems}
        <item id="css" href="style.css" media-type="text/css"/>
    </manifest>
    <spine toc="toc">
        <itemref idref="cover"/>
        <itemref idref="nav"/>
${spineItems}
    </spine>
</package>`;
        await fs.writeFile(path.join(oebpsDir, 'content.opf'), contentOpf);

        // ========== OEBPS/toc.ncx ==========
        const navPoints = storyData.chapters.map((ch, i) => 
            `        <navPoint id="chapter${i}" playOrder="${i + 3}">
            <navLabel><text>${escapeXml(ch.title)}</text></navLabel>
            <content src="chapter${i}.xhtml"/>
        </navPoint>`
        ).join('\n');

        const tocNcx = `<?xml version="1.0" encoding="UTF-8"?>
<ncx version="2005-1" xmlns="http://www.daisy.org/z3986/2005/ncx/">
    <head>
        <meta name="dtb:uid" content="urn:uuid:${uuid}"/>
        <meta name="dtb:depth" content="1"/>
        <meta name="dtb:totalPageCount" content="0"/>
        <meta name="dtb:maxPageNumber" content="0"/>
    </head>
    <docTitle><text>${escapeXml(storyData.title)}</text></docTitle>
    <navMap>
        <navPoint id="cover" playOrder="1">
            <navLabel><text>Cover</text></navLabel>
            <content src="cover.xhtml"/>
        </navPoint>
        <navPoint id="toc" playOrder="2">
            <navLabel><text>Table of Contents</text></navLabel>
            <content src="nav.xhtml"/>
        </navPoint>
${navPoints}
    </navMap>
</ncx>`;
        await fs.writeFile(path.join(oebpsDir, 'toc.ncx'), tocNcx);

        // ========== OEBPS/nav.xhtml ==========
        const tocLinks = storyData.chapters.map((ch, i) => 
            `                <li><a href="chapter${i}.xhtml">${escapeXml(ch.title)}</a></li>`
        ).join('\n');

        const navXhtml = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops">
<head>
    <title>Table of Contents</title>
    <link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body>
    <nav epub:type="toc" id="toc">
        <h1>Table of Contents</h1>
        <ol>
            <li><a href="cover.xhtml">Cover</a></li>
            <li><a href="nav.xhtml">Table of Contents</a></li>
${tocLinks}
        </ol>
    </nav>
</body>
</html>`;
        await fs.writeFile(path.join(oebpsDir, 'nav.xhtml'), navXhtml);

        // ========== OEBPS/cover.xhtml ==========
        const coverXhtml = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Cover</title>
    <link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body class="cover">
    <div class="cover-page">
        <h1 class="cover-title">${escapeXml(storyData.title)}</h1>
        <p class="cover-author">by ${escapeXml(storyData.author)}</p>
        ${storyData.description ? `<p class="cover-desc">${escapeXml(storyData.description)}</p>` : ''}
        <p class="cover-source">Downloaded from Wattpad</p>
    </div>
</body>
</html>`;
        await fs.writeFile(path.join(oebpsDir, 'cover.xhtml'), coverXhtml);

        // ========== OEBPS/style.css ==========
        const css = `/* EPUB Styles */
body {
    font-family: Georgia, "Times New Roman", serif;
    font-size: 1em;
    line-height: 1.6;
    color: #333;
    margin: 0;
    padding: 1em;
}

.cover-page {
    text-align: center;
    padding-top: 20%;
}

.cover-title {
    font-size: 2.5em;
    font-weight: bold;
    color: #1a1a2e;
    margin-bottom: 0.5em;
}

.cover-author {
    font-size: 1.5em;
    font-style: italic;
    color: #a855f7;
    margin-bottom: 1em;
}

.cover-desc {
    font-size: 1em;
    color: #666;
    max-width: 80%;
    margin: 0 auto 2em;
}

.cover-source {
    font-size: 0.8em;
    color: #999;
}

h1 {
    font-size: 1.8em;
    color: #1a1a2e;
    border-bottom: 2px solid #00d4ff;
    padding-bottom: 0.3em;
    margin-top: 1.5em;
}

h2 {
    font-size: 1.4em;
    color: #333;
    margin-top: 1.2em;
}

p {
    margin: 0.8em 0;
    text-align: justify;
}

.chapter-number {
    font-size: 0.9em;
    color: #00d4ff;
    font-weight: bold;
    text-transform: uppercase;
    letter-spacing: 2px;
}

.chapter-title {
    font-size: 1.6em;
    color: #1a1a2e;
    margin: 0.3em 0 1em;
}

#toc h1 {
    text-align: center;
    border-bottom: none;
}

#toc ol {
    list-style: none;
    padding: 0;
}

#toc li {
    margin: 0.5em 0;
    padding: 0.3em 0;
    border-bottom: 1px solid #eee;
}

#toc a {
    color: #333;
    text-decoration: none;
}

#toc a:hover {
    color: #00d4ff;
}`;
        await fs.writeFile(path.join(oebpsDir, 'style.css'), css);

        // ========== Generate Chapter Files ==========
        for (let i = 0; i < storyData.chapters.length; i++) {
            const chapter = storyData.chapters[i];
            const chapterHtml = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>${escapeXml(chapter.title)}</title>
    <link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body>
    <div class="chapter">
        <p class="chapter-number">Chapter ${chapter.number}</p>
        <h1 class="chapter-title">${escapeXml(chapter.title)}</h1>
        ${formatContent(chapter.content)}
    </div>
</body>
</html>`;
            await fs.writeFile(path.join(oebpsDir, `chapter${i}.xhtml`), chapterHtml);
        }

        // ========== Create ZIP (EPUB is a ZIP file) ==========
        await createZip(tempDir, outputPath);

        console.log(`EPUB generated: ${outputPath}`);

    } catch (error) {
        console.error('EPUB Generation Error:', error);
        throw error;
    } finally {
        // Cleanup temp directory
        await fs.remove(tempDir).catch(() => {});
    }
};

/**
 * Create ZIP archive from directory
 * Simple implementation using Node.js built-in modules
 */
async function createZip(sourceDir, outputPath) {
    const archiver = require('archiver');
    const output = fs.createWriteStream(outputPath);
    const archive = archiver('zip', { zlib: { level: 9 } });

    return new Promise((resolve, reject) => {
        output.on('close', () => resolve());
        archive.on('error', (err) => reject(err));

        archive.pipe(output);

        // Add mimetype first (must be uncompressed and first in EPUB)
        const mimetypePath = path.join(sourceDir, 'mimetype');
        if (fs.existsSync(mimetypePath)) {
            archive.append(fs.createReadStream(mimetypePath), { 
                name: 'mimetype',
                store: true // uncompressed
            });
        }

        // Add rest of files
        archive.directory(path.join(sourceDir, 'META-INF'), 'META-INF');
        archive.directory(path.join(sourceDir, 'OEBPS'), 'OEBPS');

        archive.finalize();
    });
}

/**
 * Escape XML special characters
 */
function escapeXml(text) {
    if (!text) return '';
    return text
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&apos;');
}

/**
 * Format plain text content into HTML paragraphs
 */
function formatContent(text) {
    if (!text) return '<p></p>';

    // Split by double newlines or single newlines to create paragraphs
    const paragraphs = text
        .split(/\n\n+|\n/)
        .map(p => p.trim())
        .filter(p => p.length > 0);

    if (paragraphs.length === 0) {
        return `<p>${escapeXml(text)}</p>`;
    }

    return paragraphs.map(p => `<p>${escapeXml(p)}</p>`).join('\n        ');
}
