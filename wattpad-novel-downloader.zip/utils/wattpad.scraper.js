/**
 * Wattpad Scraper Utility
 * Fetches story metadata, chapters, and content from Wattpad URLs
 * Uses Axios + Cheerio for HTML parsing
 */

const axios = require('axios');
const cheerio = require('cheerio');

// Axios instance with browser-like headers
const httpClient = axios.create({
    timeout: 30000,
    headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'gzip, deflate, br',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1'
    }
});

/**
 * Fetch story data from Wattpad URL
 * @param {string} url - Wattpad story URL
 * @returns {Object} Story data with title, author, chapters, etc.
 */
exports.fetchStory = async (url) => {
    try {
        // Fetch the main story page
        const response = await httpClient.get(url);
        const $ = cheerio.load(response.data);

        // Extract story metadata
        const title = extractTitle($);
        const author = extractAuthor($);
        const description = extractDescription($);
        const coverImage = extractCoverImage($);
        const chapterUrls = extractChapterUrls($, url);

        if (chapterUrls.length === 0) {
            throw new Error('No chapters found. The story may be private or removed.');
        }

        // Fetch all chapter contents
        const chapters = [];
        for (let i = 0; i < chapterUrls.length; i++) {
            const chapterUrl = chapterUrls[i];
            console.log(`Fetching chapter ${i + 1}/${chapterUrls.length}: ${chapterUrl}`);

            try {
                const chapterData = await fetchChapter(chapterUrl, i + 1);
                if (chapterData) {
                    chapters.push(chapterData);
                }
            } catch (err) {
                console.warn(`Failed to fetch chapter ${i + 1}:`, err.message);
                // Continue with other chapters
            }
        }

        // Sanitize title for filename
        const sanitizedTitle = title.replace(/[^a-zA-Z0-9\s]/g, '').replace(/\s+/g, '_').substring(0, 50);

        return {
            title,
            author,
            description,
            coverImage,
            chapters,
            sanitizedTitle,
            sourceUrl: url
        };

    } catch (error) {
        console.error('Scraper Error:', error.message);
        throw new Error(`Failed to fetch story: ${error.message}`);
    }
};

/**
 * Extract story title from page
 */
function extractTitle($) {
    // Try multiple selectors for title
    const selectors = [
        'h1.story-title',
        'h1[data-testid="story-title"]',
        '.story-info__title',
        'meta[property="og:title"]',
        'title'
    ];

    for (const selector of selectors) {
        const el = $(selector);
        if (el.length) {
            const text = selector.includes('meta') ? el.attr('content') : el.text().trim();
            if (text && text !== 'Wattpad') {
                return text.replace(' - Wattpad', '').trim();
            }
        }
    }

    return 'Untitled Story';
}

/**
 * Extract author name from page
 */
function extractAuthor($) {
    const selectors = [
        '.author-info__username',
        'a[href^="/user/"]',
        'meta[name="author"]',
        '.story-info__author'
    ];

    for (const selector of selectors) {
        const el = $(selector);
        if (el.length) {
            const text = selector.includes('meta') ? el.attr('content') : el.text().trim();
            if (text) return text;
        }
    }

    return 'Unknown Author';
}

/**
 * Extract story description
 */
function extractDescription($) {
    const selectors = [
        '.description',
        '[data-testid="story-description"]',
        'meta[property="og:description"]',
        '.story-info__description'
    ];

    for (const selector of selectors) {
        const el = $(selector);
        if (el.length) {
            const text = selector.includes('meta') ? el.attr('content') : el.text().trim();
            if (text) return text;
        }
    }

    return '';
}

/**
 * Extract cover image URL
 */
function extractCoverImage($) {
    const selectors = [
        'meta[property="og:image"]',
        '.story-cover img',
        '.cover img'
    ];

    for (const selector of selectors) {
        const el = $(selector);
        if (el.length) {
            const src = selector.includes('meta') ? el.attr('content') : el.attr('src');
            if (src) return src;
        }
    }

    return null;
}

/**
 * Extract all chapter URLs from the story page
 */
function extractChapterUrls($, baseUrl) {
    const urls = [];
    const seen = new Set();

    // Look for chapter links in table of contents
    $('a[href*="/"]').each((i, el) => {
        const href = $(el).attr('href');
        if (href && href.match(/\d+$/) && !seen.has(href)) {
            // Check if it looks like a chapter link
            const fullUrl = href.startsWith('http') ? href : `https://www.wattpad.com${href}`;
            if (fullUrl.includes('/')) {
                seen.add(href);
                urls.push(fullUrl);
            }
        }
    });

    // If no chapters found via links, try to construct from base URL
    if (urls.length === 0) {
        // Try to find story ID and construct chapter URLs
        const storyMatch = baseUrl.match(/(\d+)/);
        if (storyMatch) {
            // Add the base URL as first chapter
            urls.push(baseUrl);
        }
    }

    return urls;
}

/**
 * Fetch individual chapter content
 */
async function fetchChapter(url, chapterNum) {
    try {
        const response = await httpClient.get(url);
        const $ = cheerio.load(response.data);

        // Extract chapter title
        let chapterTitle = '';
        const titleSelectors = ['h1', 'h2', '.chapter-title', '[data-testid="chapter-title"]'];
        for (const selector of titleSelectors) {
            const el = $(selector);
            if (el.length) {
                chapterTitle = el.first().text().trim();
                if (chapterTitle) break;
            }
        }

        if (!chapterTitle) {
            chapterTitle = `Chapter ${chapterNum}`;
        }

        // Extract chapter content
        let content = '';
        const contentSelectors = [
            '.story-text',
            '.chapter-content',
            '[data-testid="story-text"]',
            'article',
            '.page-content'
        ];

        for (const selector of contentSelectors) {
            const el = $(selector);
            if (el.length) {
                // Get text and clean it up
                content = el.text().trim();
                if (content.length > 100) break;
            }
        }

        // Fallback: get paragraphs from main content area
        if (!content || content.length < 100) {
            const paragraphs = [];
            $('p').each((i, el) => {
                const text = $(el).text().trim();
                if (text.length > 20) {
                    paragraphs.push(text);
                }
            });
            content = paragraphs.join('\n\n');
        }

        if (!content || content.length < 50) {
            throw new Error('Chapter content too short or empty');
        }

        return {
            number: chapterNum,
            title: chapterTitle,
            content: content,
            url: url
        };

    } catch (error) {
        console.error(`Error fetching chapter ${chapterNum}:`, error.message);
        throw error;
    }
}
