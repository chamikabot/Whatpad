/**
 * File Cleaner Utility
 * Automatically deletes old generated files to save disk space
 */

const fs = require('fs-extra');
const path = require('path');

/**
 * Schedule cleanup of a directory after specified time
 * @param {string} dirPath - Directory to clean up
 * @param {number} delayMs - Delay in milliseconds before deletion
 */
exports.scheduleCleanup = (dirPath, delayMs = 3600000) => {
    setTimeout(async () => {
        try {
            if (await fs.pathExists(dirPath)) {
                await fs.remove(dirPath);
                console.log(`[Cleanup] Deleted: ${dirPath}`);
            }
        } catch (error) {
            console.error(`[Cleanup] Failed to delete ${dirPath}:`, error.message);
        }
    }, delayMs);
};

/**
 * Clean all old files in downloads directory
 * Removes files older than specified hours
 * @param {number} maxAgeHours - Maximum age in hours
 */
exports.cleanOldFiles = async (downloadsDir, maxAgeHours = 24) => {
    try {
        const entries = await fs.readdir(downloadsDir);
        const now = Date.now();
        const maxAgeMs = maxAgeHours * 60 * 60 * 1000;

        for (const entry of entries) {
            const entryPath = path.join(downloadsDir, entry);
            const stats = await fs.stat(entryPath);
            const age = now - stats.mtime.getTime();

            if (age > maxAgeMs) {
                await fs.remove(entryPath);
                console.log(`[Cleanup] Deleted old file: ${entry}`);
            }
        }
    } catch (error) {
        console.error('[Cleanup] Error cleaning old files:', error.message);
    }
};
