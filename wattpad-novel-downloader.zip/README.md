# ⚡ Wattpad Novel Downloader

A modern, production-ready full-stack web application that downloads Wattpad novels and converts them into beautifully formatted **PDF** and **EPUB** ebooks. Built with Node.js, Express, and a stunning cyberpunk dark UI.

![Node.js](https://img.shields.io/badge/Node.js-16+-green?logo=node.js)
![Express](https://img.shields.io/badge/Express-4.18+-blue?logo=express)
![License](https://img.shields.io/badge/License-MIT-purple)

## ✨ Features

| Feature | Description |
|---------|-------------|
| **PDF Generation** | Professional PDFs with TOC, chapter headers, and elegant typography |
| **EPUB Export** | Standard EPUB 3.0 compatible with all e-readers (Kindle, Kobo, Apple Books) |
| **Auto Chapter Fetch** | Automatically discovers and downloads all available chapters |
| **Dark Neon UI** | Cyberpunk glassmorphism design with animated particle background |
| **Responsive** | Fully mobile-friendly layout that works on all devices |
| **Rate Limiting** | API protection with configurable request limits |
| **Auto Cleanup** | Generated files automatically deleted after 1 hour |
| **Error Handling** | Graceful error states with retry functionality |
| **Toast Notifications** | Beautiful non-blocking success/error notifications |
| **Copy-Paste Support** | One-click paste from clipboard |

## 🚀 Quick Start

### Prerequisites
- Node.js 16+ installed
- npm or yarn package manager

### Installation

```bash
# 1. Clone or extract the project
cd wattpad-novel-downloader

# 2. Install dependencies
npm install

# 3. Start the server
npm start

# 4. Open in browser
# Navigate to http://localhost:3000
```

### Development Mode
```bash
npm run dev
```

## 📁 Project Structure

```
wattpad-novel-downloader/
├── server.js                    # Main Express server
├── package.json                 # Dependencies & scripts
├── README.md                    # This file
├── public/
│   ├── index.html              # Main frontend
│   ├── 404.html                # Custom error page
│   ├── css/
│   │   └── style.css           # Dark neon styling
│   ├── js/
│   │   └── script.js           # Frontend logic
│   └── images/                 # Static images
├── routes/
│   └── novel.routes.js         # API route definitions
├── controllers/
│   └── novel.controller.js     # Business logic
├── utils/
│   ├── wattpad.scraper.js      # Wattpad scraping
│   ├── pdf.generator.js        # PDF generation
│   ├── epub.generator.js       # EPUB generation
│   └── file.cleaner.js         # File cleanup
├── downloads/                   # Generated files (auto-created)
└── views/                       # View templates (if needed)
```

## 🔌 API Endpoints

### POST `/api/novel/download`
Download a Wattpad novel and generate PDF/EPUB.

**Request:**
```json
{
  "url": "https://www.wattpad.com/story/123456789-story-title"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Novel downloaded and formatted successfully!",
  "data": {
    "title": "Story Title",
    "author": "Author Name",
    "chapterCount": 25,
    "description": "Story description...",
    "coverImage": "https://...",
    "downloads": {
      "pdf": {
        "filename": "Story_Title_abc123.pdf",
        "url": "/api/novel/download/abc123/Story_Title_abc123.pdf"
      },
      "epub": {
        "filename": "Story_Title_abc123.epub",
        "url": "/api/novel/download/abc123/Story_Title_abc123.epub"
      }
    }
  }
}
```

### GET `/api/novel/download/:sessionId/:filename`
Download a generated file.

### GET `/api/health`
Health check endpoint.

## 🎨 UI Features

- **Particle Background** — Animated canvas particles with connection lines
- **Glassmorphism Cards** — Frosted glass effect with backdrop blur
- **Neon Glow Effects** — Blue/purple gradient accents and glows
- **Smooth Animations** — Fade-in, scale, and hover transitions
- **Loading Animation** — Orbital planet/moon spinner with progress bar
- **Success Modal** — Animated download confirmation
- **Toast Notifications** — Non-blocking feedback messages
- **Custom Scrollbar** — Styled scrollbar matching the dark theme

## 🛡️ Security Features

- **Helmet.js** — Secure HTTP headers
- **Rate Limiting** — 10 requests per 15 minutes per IP
- **CORS** — Configurable cross-origin support
- **Path Traversal Protection** — Safe file serving
- **Input Validation** — URL format validation

## ⚙️ Configuration

Environment variables (optional):

```env
PORT=3000                    # Server port
NODE_ENV=production          # Environment mode
```

## 📝 Tech Stack

| Layer | Technology |
|-------|-----------|
| **Backend** | Node.js, Express.js |
| **Scraping** | Axios, Cheerio |
| **PDF** | PDFKit |
| **EPUB** | Custom ZIP generator (archiver) |
| **Frontend** | Vanilla HTML5, CSS3, JavaScript |
| **Security** | Helmet, express-rate-limit, CORS |

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License.

## ⚠️ Disclaimer

This tool is for personal use only. Please respect Wattpad's Terms of Service and authors' rights. Only download stories you have permission to access.

---

Built with ❤️ using Node.js, Express & a lot of coffee.
