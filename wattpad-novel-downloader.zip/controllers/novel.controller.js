/**
 * Novel Controller - Business Logic for Novel Downloading
 * Handles Wattpad scraping, PDF/EPUB generation, and file serving
 */

const path = require('path');
const fs = require('fs-extra');
const { v4: uuidv4 } = require('uuid');
const wattpadScraper = require('../utils/wattpad.scraper');
const pdfGenerator = require('../utils/pdf.generator');
const epubGenerator = require('../utils/epub.generator');
const fileCleaner = require('../utils/file.cleaner');

const downloadsDir = path.join(__dirname, '..', 'downloads');

/**
 * Download Novel - Main controller for processing Wattpad URLs
 * Fetches story data, generates PDF and EPUB, returns download links
 */
exports.downloadNovel = async (req, res) => {
    try {
        const { url } = req.body;

        // Validate URL
        if (!url || typeof url !== 'string' || url.trim() === '') {
            return res.status(400).json({
                success: false,
                message: 'Please provide a valid Wattpad story URL'
            });
        }

        // Validate Wattpad URL format
        const wattpadRegex = /^https?:\/\/(www\.)?wattpad\.com\/(story|)\/\d+.*$/i;
        if (!wattpadRegex.test(url)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid Wattpad URL. Please provide a valid Wattpad story link.'
            });
        }

        // Generate unique session ID for this download
        const sessionId = uuidv4();
        const sessionDir = path.join(downloadsDir, sessionId);
        await fs.ensureDir(sessionDir);

        console.log(`[${sessionId}] Starting download for: ${url}`);

        // Step 1: Scrape Wattpad story data
        console.log(`[${sessionId}] Fetching story data...`);
        const storyData = await wattpadScraper.fetchStory(url);

        if (!storyData || !storyData.chapters || storyData.chapters.length === 0) {
            await fs.remove(sessionDir);
            return res.status(404).json({
                success: false,
                message: 'Could not fetch story data. The story may be private or unavailable.'
            });
        }

        console.log(`[${sessionId}] Found ${storyData.chapters.length} chapters`);

        // Step 2: Generate PDF
        console.log(`[${sessionId}] Generating PDF...`);
        const pdfFilename = `${storyData.sanitizedTitle}_${sessionId}.pdf`;
        const pdfPath = path.join(sessionDir, pdfFilename);
        await pdfGenerator.generate(storyData, pdfPath);

        // Step 3: Generate EPUB
        console.log(`[${sessionId}] Generating EPUB...`);
        const epubFilename = `${storyData.sanitizedTitle}_${sessionId}.epub`;
        const epubPath = path.join(sessionDir, epubFilename);
        await epubGenerator.generate(storyData, epubPath);

        // Step 4: Schedule cleanup (delete files after 1 hour)
        fileCleaner.scheduleCleanup(sessionDir, 60 * 60 * 1000);

        console.log(`[${sessionId}] Download ready!`);

        // Return success response with download links
        res.json({
            success: true,
            message: 'Novel downloaded and formatted successfully!',
            data: {
                title: storyData.title,
                author: storyData.author,
                chapterCount: storyData.chapters.length,
                description: storyData.description,
                coverImage: storyData.coverImage,
                downloads: {
                    pdf: {
                        filename: pdfFilename,
                        url: `/api/novel/download/${sessionId}/${pdfFilename}`
                    },
                    epub: {
                        filename: epubFilename,
                        url: `/api/novel/download/${sessionId}/${epubFilename}`
                    }
                }
            }
        });

    } catch (error) {
        console.error('Download Error:', error);
        res.status(500).json({
            success: false,
            message: error.message || 'Failed to download novel. Please try again.'
        });
    }
};

/**
 * Serve File - Stream generated files for download
 */
exports.serveFile = async (req, res) => {
    try {
        const { sessionId, filename } = req.params;

        // Security: Validate path components
        if (!sessionId || !filename) {
            return res.status(400).json({
                success: false,
                message: 'Invalid download link'
            });
        }

        // Prevent directory traversal attacks
        if (sessionId.includes('..') || filename.includes('..')) {
            return res.status(403).json({
                success: false,
                message: 'Access denied'
            });
        }

        const filePath = path.join(downloadsDir, sessionId, filename);

        // Check if file exists
        if (!await fs.pathExists(filePath)) {
            return res.status(404).json({
                success: false,
                message: 'File not found or expired'
            });
        }

        // Determine content type
        const ext = path.extname(filename).toLowerCase();
        let contentType = 'application/octet-stream';
        if (ext === '.pdf') contentType = 'application/pdf';
        if (ext === '.epub') contentType = 'application/epub+zip';

        // Set headers for download
        res.setHeader('Content-Type', contentType);
        res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
        res.setHeader('Cache-Control', 'no-cache');

        // Stream the file
        const fileStream = fs.createReadStream(filePath);
        fileStream.pipe(res);

        fileStream.on('error', (err) => {
            console.error('File stream error:', err);
            if (!res.headersSent) {
                res.status(500).json({
                    success: false,
                    message: 'Error streaming file'
                });
            }
        });

    } catch (error) {
        console.error('Serve File Error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to serve file'
        });
    }
};
