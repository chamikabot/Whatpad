/**
 * Novel Routes - API Endpoints for Wattpad Novel Downloading
 * Handles PDF/EPUB generation requests
 */

const express = require('express');
const router = express.Router();
const novelController = require('../controllers/novel.controller');

// POST /api/novel/download - Generate PDF and EPUB from Wattpad URL
router.post('/download', novelController.downloadNovel);

// GET /api/novel/download/:filename - Download generated file
router.get('/download/:filename', novelController.serveFile);

module.exports = router;
