/**
 * Wattpad Novel Downloader - Frontend JavaScript
 * Handles UI interactions, API calls, particle background, and state management
 */

document.addEventListener('DOMContentLoaded', () => {
    // ============================================
    // DOM Elements
    // ============================================
    const urlInput = document.getElementById('novel-url');
    const generateBtn = document.getElementById('generate-btn');
    const pasteBtn = document.getElementById('paste-btn');
    const clearBtn = document.getElementById('clear-btn');
    const retryBtn = document.getElementById('retry-btn');
    const downloadAgainBtn = document.getElementById('download-again');
    const modalCloseBtn = document.getElementById('modal-close');

    const inputWrapper = document.getElementById('input-wrapper');
    const panelHeader = document.querySelector('.panel-header');

    const loadingState = document.getElementById('loading-state');
    const previewState = document.getElementById('preview-state');
    const successState = document.getElementById('success-state');
    const errorState = document.getElementById('error-state');

    const progressFill = document.getElementById('progress-fill');
    const progressPercent = document.getElementById('progress-percent');
    const progressDetail = document.getElementById('progress-detail');
    const loadingText = document.getElementById('loading-text');

    const previewTitle = document.getElementById('preview-title');
    const previewAuthor = document.getElementById('preview-author');
    const previewDesc = document.getElementById('preview-desc');
    const chapterCount = document.getElementById('chapter-count');
    const coverImg = document.getElementById('cover-img');
    const coverPlaceholder = document.querySelector('.cover-placeholder');

    const downloadPdfBtn = document.getElementById('download-pdf');
    const downloadEpubBtn = document.getElementById('download-epub');
    const errorText = document.getElementById('error-text');

    const toastContainer = document.getElementById('toast-container');
    const successModal = document.getElementById('success-modal');

    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const navLinks = document.querySelector('.nav-links');

    // API Base URL
    const API_BASE = window.location.origin;

    // ============================================
    // Particle Background System
    // ============================================
    const canvas = document.getElementById('particle-canvas');
    const ctx = canvas.getContext('2d');
    let particles = [];
    let animationId = null;

    function initParticles() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;

        const particleCount = window.innerWidth < 768 ? 30 : 60;
        particles = [];

        for (let i = 0; i < particleCount; i++) {
            particles.push({
                x: Math.random() * canvas.width,
                y: Math.random() * canvas.height,
                vx: (Math.random() - 0.5) * 0.5,
                vy: (Math.random() - 0.5) * 0.5,
                radius: Math.random() * 2 + 0.5,
                opacity: Math.random() * 0.5 + 0.1,
                color: Math.random() > 0.5 ? '0, 212, 255' : '168, 85, 247'
            });
        }
    }

    function animateParticles() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        particles.forEach((p, i) => {
            // Update position
            p.x += p.vx;
            p.y += p.vy;

            // Wrap around edges
            if (p.x < 0) p.x = canvas.width;
            if (p.x > canvas.width) p.x = 0;
            if (p.y < 0) p.y = canvas.height;
            if (p.y > canvas.height) p.y = 0;

            // Draw particle
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(${p.color}, ${p.opacity})`;
            ctx.fill();

            // Draw connections
            particles.slice(i + 1).forEach(p2 => {
                const dx = p.x - p2.x;
                const dy = p.y - p2.y;
                const dist = Math.sqrt(dx * dx + dy * dy);

                if (dist < 120) {
                    ctx.beginPath();
                    ctx.moveTo(p.x, p.y);
                    ctx.lineTo(p2.x, p2.y);
                    ctx.strokeStyle = `rgba(${p.color}, ${0.1 * (1 - dist / 120)})`;
                    ctx.lineWidth = 0.5;
                    ctx.stroke();
                }
            });
        });

        animationId = requestAnimationFrame(animateParticles);
    }

    // Initialize particles
    initParticles();
    animateParticles();

    // Handle resize
    window.addEventListener('resize', () => {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
        initParticles();
    });

    // ============================================
    // Toast Notification System
    // ============================================
    function showToast(message, type = 'info', duration = 4000) {
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;

        const iconSvg = type === 'success' 
            ? '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#22c55e" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>'
            : type === 'error'
            ? '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>'
            : '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#00d4ff" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>';

        toast.innerHTML = `${iconSvg}<span>${message}</span>`;
        toastContainer.appendChild(toast);

        // Auto remove
        setTimeout(() => {
            toast.style.animation = 'toastOut 0.3s ease forwards';
            setTimeout(() => toast.remove(), 300);
        }, duration);
    }

    // ============================================
    // Modal System
    // ============================================
    function showModal() {
        successModal.classList.remove('hidden');
        document.body.style.overflow = 'hidden';
    }

    function hideModal() {
        successModal.classList.add('hidden');
        document.body.style.overflow = '';
    }

    // ============================================
    // State Management
    // ============================================
    function showState(state) {
        // Hide all states
        loadingState.classList.add('hidden');
        previewState.classList.add('hidden');
        successState.classList.add('hidden');
        errorState.classList.add('hidden');

        // Show/hide input elements
        if (state === 'input') {
            inputWrapper.style.display = 'block';
            generateBtn.style.display = 'block';
            panelHeader.style.display = 'block';
            generateBtn.disabled = false;
        } else {
            inputWrapper.style.display = 'none';
            generateBtn.style.display = 'none';
            panelHeader.style.display = 'none';
        }

        switch (state) {
            case 'loading':
                loadingState.classList.remove('hidden');
                break;
            case 'preview':
                previewState.classList.remove('hidden');
                break;
            case 'success':
                successState.classList.remove('hidden');
                break;
            case 'error':
                errorState.classList.remove('hidden');
                break;
            default:
                break;
        }
    }

    // ============================================
    // Progress Simulation
    // ============================================
    let progressInterval = null;

    function startProgress() {
        let progress = 0;
        const stages = [
            { at: 0, text: 'Connecting to Wattpad...', detail: 'Initializing' },
            { at: 15, text: 'Fetching story metadata...', detail: 'Reading story info' },
            { at: 30, text: 'Discovering chapters...', detail: 'Scanning chapters' },
            { at: 50, text: 'Downloading chapters...', detail: 'Fetching content' },
            { at: 75, text: 'Formatting content...', detail: 'Building ebook' },
            { at: 90, text: 'Finalizing...', detail: 'Almost done' }
        ];

        progressInterval = setInterval(() => {
            progress += Math.random() * 3 + 0.5;
            if (progress > 95) progress = 95;

            const currentStage = stages.reverse().find(s => progress >= s.at);
            stages.reverse(); // Restore order

            if (currentStage) {
                loadingText.textContent = currentStage.text;
                progressDetail.textContent = currentStage.detail;
            }

            progressFill.style.width = progress + '%';
            progressPercent.textContent = Math.floor(progress) + '%';

        }, 200);
    }

    function stopProgress() {
        if (progressInterval) {
            clearInterval(progressInterval);
            progressInterval = null;
        }
        progressFill.style.width = '100%';
        progressPercent.textContent = '100%';
    }

    // ============================================
    // Download Novel
    // ============================================
    async function downloadNovel() {
        const url = urlInput.value.trim();

        if (!url) {
            showToast('Please enter a Wattpad story URL', 'error');
            urlInput.focus();
            return;
        }

        // Basic URL validation
        if (!url.includes('wattpad.com')) {
            showToast('Please enter a valid Wattpad URL', 'error');
            return;
        }

        showState('loading');
        startProgress();
        generateBtn.disabled = true;

        try {
            const response = await fetch(`${API_BASE}/api/novel/download`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ url })
            });

            const data = await response.json();

            if (!response.ok || !data.success) {
                throw new Error(data.message || 'Failed to download novel');
            }

            stopProgress();

            // Update preview
            previewTitle.textContent = data.data.title;
            previewAuthor.textContent = `by ${data.data.author}`;
            previewDesc.textContent = data.data.description || 'No description available.';
            chapterCount.textContent = `${data.data.chapterCount} chapters`;

            if (data.data.coverImage) {
                coverImg.src = data.data.coverImage;
                coverImg.classList.remove('hidden');
                coverPlaceholder.classList.add('hidden');
            } else {
                coverImg.classList.add('hidden');
                coverPlaceholder.classList.remove('hidden');
            }

            // Set download links
            downloadPdfBtn.href = data.data.downloads.pdf.url;
            downloadPdfBtn.download = data.data.downloads.pdf.filename;
            downloadEpubBtn.href = data.data.downloads.epub.url;
            downloadEpubBtn.download = data.data.downloads.epub.filename;

            // Show success
            showState('success');
            showToast('Novel downloaded successfully!', 'success');

        } catch (error) {
            stopProgress();
            console.error('Download Error:', error);
            errorText.textContent = error.message || 'Failed to download the novel. Please check the URL and try again.';
            showState('error');
            showToast(error.message || 'Download failed', 'error');
        } finally {
            generateBtn.disabled = false;
        }
    }

    // ============================================
    // Reset Form
    // ============================================
    function resetForm() {
        urlInput.value = '';
        coverImg.src = '';
        coverImg.classList.add('hidden');
        coverPlaceholder.classList.remove('hidden');
        progressFill.style.width = '0%';
        progressPercent.textContent = '0%';
        showState('input');
    }

    // ============================================
    // Event Listeners
    // ============================================

    // Generate button
    generateBtn.addEventListener('click', downloadNovel);

    // Enter key
    urlInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            downloadNovel();
        }
    });

    // Paste button
    pasteBtn.addEventListener('click', async () => {
        try {
            const text = await navigator.clipboard.readText();
            urlInput.value = text;
            urlInput.focus();
            showToast('URL pasted from clipboard', 'success', 2000);

            // Show clear button
            pasteBtn.classList.add('hidden');
            clearBtn.classList.remove('hidden');
        } catch (err) {
            showToast('Unable to access clipboard. Please paste manually.', 'error');
        }
    });

    // Clear button
    clearBtn.addEventListener('click', () => {
        urlInput.value = '';
        urlInput.focus();
        clearBtn.classList.add('hidden');
        pasteBtn.classList.remove('hidden');
    });

    // Input change - toggle buttons
    urlInput.addEventListener('input', () => {
        if (urlInput.value.trim()) {
            pasteBtn.classList.add('hidden');
            clearBtn.classList.remove('hidden');
        } else {
            pasteBtn.classList.remove('hidden');
            clearBtn.classList.add('hidden');
        }
    });

    // Retry button
    retryBtn.addEventListener('click', () => {
        showState('input');
        urlInput.focus();
    });

    // Download again button
    downloadAgainBtn.addEventListener('click', resetForm);

    // Download buttons - show modal
    downloadPdfBtn.addEventListener('click', () => {
        setTimeout(showModal, 300);
    });

    downloadEpubBtn.addEventListener('click', () => {
        setTimeout(showModal, 300);
    });

    // Modal close
    modalCloseBtn.addEventListener('click', hideModal);
    document.querySelector('.modal-overlay').addEventListener('click', hideModal);

    // Mobile menu toggle
    mobileMenuBtn.addEventListener('click', () => {
        navLinks.classList.toggle('active');
        mobileMenuBtn.classList.toggle('active');
    });

    // Smooth scroll for navigation
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            if (href !== '#') {
                e.preventDefault();
                const target = document.querySelector(href);
                if (target) {
                    const offset = 100;
                    const targetPosition = target.getBoundingClientRect().top + window.pageYOffset - offset;
                    window.scrollTo({
                        top: targetPosition,
                        behavior: 'smooth'
                    });
                }
            }
        });
    });

    // Navbar scroll effect
    let lastScroll = 0;
    window.addEventListener('scroll', () => {
        const navbar = document.querySelector('.navbar');
        const currentScroll = window.pageYOffset;

        if (currentScroll > 50) {
            navbar.style.background = 'rgba(5, 5, 8, 0.9)';
            navbar.style.boxShadow = '0 4px 30px rgba(0, 0, 0, 0.3)';
        } else {
            navbar.style.background = 'rgba(5, 5, 8, 0.7)';
            navbar.style.boxShadow = 'none';
        }

        lastScroll = currentScroll;
    });

    // ============================================
    // Console Art
    // ============================================
    console.log('%c⚡ Wattpad Novel Downloader ⚡', 'background: linear-gradient(135deg, #00d4ff, #a855f7); color: #fff; font-size: 24px; font-weight: bold; padding: 12px 24px; border-radius: 12px;');
    console.log('%cReady to transform stories into ebooks!', 'color: #a855f7; font-size: 14px; font-family: monospace;');
});
